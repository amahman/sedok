const fs = require('fs');
const axios = require('axios');
module.exports = async ({ lunaticreply, isAdmin, isOwner }) => {
// 🔒 Hanya admin/owner
if (!isAdmin && !isOwner) {
return lunaticreply('❌ Fitur ini hanya bisa digunakan oleh Admin atau Owner.');
}
// 🔐 Ambil token
let token;
try {
const tk = JSON.parse(fs.readFileSync('./avars/tokengh.json'));
token = tk.token;
} catch {
return lunaticreply(`❌ Gagal membaca token GitHub di avars/tokengh.json`);
}
if (!token) {
return lunaticreply(`❌ Token GitHub belum diset!`);
}
const owner = 'ianexec';
const repo = 'permission';
const path = 'regist';
const apiUrl = `https://api.github.com/repos/${owner}/${repo}/contents/${path}`;
try {
// 📥 Ambil isi file dari GitHub
const { data } = await axios.get(apiUrl, {
headers: {
Authorization: `Bearer ${token}`,
Accept: 'application/vnd.github.v3+json',
},
});
const content = Buffer.from(data.content, 'base64').toString();
const lines = content.split('\n').filter(l => l.startsWith('###'));
if (lines.length === 0) return lunaticreply('⚠️ Tidak ada data regist.');
const now = new Date();
const hasil = lines.map(line => {
const parts = line.replace('###', '').trim().split(/\s+/);
const [nama, tanggal, ip] = parts;
const expire = new Date(tanggal);
const diffMs = expire - now;
const diffDays = Math.ceil(diffMs / (1000 * 60 * 60 * 24));
let status = '🟥 EXPIRED';
if (diffDays > 10) {
status = '🟩 Aktif';
} else if (diffDays > 0) {
status = '🟧 Hampir Expired';
}
const expiredInfo = diffDays > 0
? `${diffDays} day | ${tanggal}`
: `0 day | ${tanggal}`;
return `==============\n` +
`NAMA   : ${nama}\n` +
`IPVPS  : ${ip}\n` +
`EXPIRED: ${expiredInfo}\n` +
`STATUS : ${status}`;
}).join('\n\n');
lunaticreply(hasil);
} catch (err) {
console.error('[LISTREGIST ERROR]', err.response?.data || err.message);
lunaticreply(`❌ Gagal mengambil data dari GitHub.`);
}
};