// cmd/crackmail.js
const axios = require('axios');

module.exports = async ({ args, lunaticreply }) => {
  const email = args[0];
  if (!email)
    return lunaticreply('❗ Format: !crackmail <email>\nContoh: !crackmail jokowi@gmail.com');

  try {
    const { data } = await axios.get(
      `https://apii.baguss.web.id/tools/gmailbocor`,
      {
        params: {
          apikey: 'bagus',
          email
        },
        timeout: 15000
      }
    );

    if (!data || !data.success)
      return lunaticreply('❌ Gagal memeriksa email (API error).');

    const { total, breaches } = data;
    let txt = `📧 *HASIL CEK EMAIL*\n\n` +
              `🆔 Email : ${email}\n` +
              `📦 Total Kebocoran : ${total}\n\n`;

    breaches.forEach((b, i) => {
      txt += `🔹 *${i + 1}. ${b.title}*\n`;
      txt += `   📅 ${b.date}\n`;
      txt += `   📄 Data : ${b.breached_data}\n`;
      txt += `   📊 Total : ${b.total_breach}\n\n`;
    });

    lunaticreply(txt.trim());
  } catch (err) {
    console.error('crackmail error:', err.message);
    lunaticreply('❌ Terjadi kesalahan saat mengecek email.');
  }
};
