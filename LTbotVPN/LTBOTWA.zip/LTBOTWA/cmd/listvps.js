const fs = require('fs');
const axios = require('axios');

module.exports = async ({ lunaticreply, isAdmin }) => {
  if (!isAdmin) return lunaticreply('❌ Hanya admin yang bisa melihat daftar VPS.');

  const tokenPath = './avars/token.json';
  if (!fs.existsSync(tokenPath)) {
    return lunaticreply('❌ File token tidak ditemukan di avars/token.json');
  }

  const { digitalocean: apiToken } = JSON.parse(fs.readFileSync(tokenPath));
  if (!apiToken) return lunaticreply('❌ Token DigitalOcean kosong!');

  try {
    const response = await axios.get('https://api.digitalocean.com/v2/droplets', {
      headers: {
        Authorization: `Bearer ${apiToken}`,
      },
    });

    const droplets = response.data.droplets;
    if (droplets.length === 0) {
      return lunaticreply('📭 Tidak ada VPS ditemukan.');
    }

    const result = droplets.map(d => {
      const ip = d.networks.v4.find(n => n.type === 'public')?.ip_address || 'Tidak ada IP';
      const size = d.size_slug || 'Unknown';

      // Konversi slug ke format RAM/BW singkat (opsional)
      const sizeMap = {
        's-1vcpu-1gb': '1GB/1TB',
        's-1vcpu-2gb': '2GB/2TB',
        's-2vcpu-2gb': '2GB/3TB',
        's-4vcpu-8gb': '8GB/4TB',
        // tambahkan sesuai kebutuhan
      };

      const ramBW = sizeMap[size] || size;

      return `====================\nNama : ${d.name}\nIpvps : ${ip}\nRam&BW : ${ramBW}`;
    }).join('\n');

    lunaticreply(result);
  } catch (err) {
    console.error('❌ Gagal ambil daftar VPS:', err?.response?.data || err.message);
    lunaticreply('❌ Gagal mengambil daftar VPS.');
  }
};
