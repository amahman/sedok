const fs = require('fs');
const axios = require('axios');
module.exports = async ({ q, lunaticreply, isAdmin, isOwner }) => {
if (!isAdmin && !isOwner) {
return lunaticreply('❌ Fitur ini hanya bisa digunakan oleh Admin atau Owner.');
}
if (!q) return lunaticreply(`❌ Format salah!\n\nContoh:\ndeleteregist lunatic\natau\ndeleteregist 188.166.246.1`);
const keyword = q.trim().toLowerCase();
// 🔐 Ambil token GitHub
let token;
try {
const tk = JSON.parse(fs.readFileSync('./avars/tokengh.json'));
token = tk.token;
} catch {
return lunaticreply(`❌ Gagal membaca token GitHub di avars/tokengh.json`);
}
if (!token) {
return lunaticreply(`❌ Token GitHub belum diset!`);
}
const owner = 'ianexec';
const repo = 'permission';
const path = 'regist';
const apiUrl = `https://api.github.com/repos/${owner}/${repo}/contents/${path}`;
try {
// 📥 Ambil isi file
const { data } = await axios.get(apiUrl, {
headers: {
Authorization: `Bearer ${token}`,
Accept: 'application/vnd.github.v3+json',
},
});
const content = Buffer.from(data.content, 'base64').toString();
const lines = content.split('\n');
const filtered = lines.filter(line => {
if (!line.startsWith('###')) return true; // skip non-data baris
return !line.toLowerCase().includes(keyword); // hapus jika mengandung keyword
});
const removedCount = lines.length - filtered.length;
if (removedCount === 0) {
return lunaticreply(`⚠️ Tidak ditemukan baris yang cocok dengan *${q}*`);
}
const newContent = filtered.join('\n').trim() + '\n';
const encoded = Buffer.from(newContent).toString('base64');
// 📤 Update file ke GitHub
await axios.put(apiUrl, {
message: `deleteregist: hapus ${q}`,
content: encoded,
sha: data.sha,
}, {
headers: {
Authorization: `Bearer ${token}`,
Accept: 'application/vnd.github.v3+json',
},
});
lunaticreply(`✅ Berhasil menghapus *${removedCount}* baris yang mengandung: *${q}*`);
} catch (err) {
console.error('[DELETEREGIST ERROR]', err.response?.data || err.message);
lunaticreply(`❌ Gagal menghapus data dari GitHub.`);
}
};