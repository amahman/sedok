const fs = require('fs');
const { Client } = require('ssh2');

module.exports = async ({ isAdmin, isOwner, args, lunaticreply }) => {
    if (!isAdmin && !isOwner) return lunaticreply("❌ ```KHUSUS LUNATIC``` ");
  // Ambil prefix dinamis
  let prefix = '!';
  try {
    const pf = JSON.parse(fs.readFileSync('./avars/prefix.json'));
    prefix = pf.prefix || '!';
  } catch {}

 // batas ambil prefix
  const [username, expired, quota, limitIP, targetVps] = args;
  if (!username || !expired || !quota || !limitIP || !targetVps) {
    return lunaticreply(`❗ Format salah!\n\n*Contoh:*\n${prefix}adtro nama expired quota limitIP namaVPS`);
  }

  let vpsData;
  try {
    vpsData = JSON.parse(fs.readFileSync('./avars/vpsdata.json'));
  } catch (err) {
    return lunaticreply('❌ Gagal membaca file vpsdata.json');
  }

  const target = vpsData[targetVps];
  if (!target) return lunaticreply(`❌ VPS "${targetVps}" tidak ditemukan!\nCek dengan: ${prefix}listvps`);

  const conn = new Client();
  conn.on('ready', () => {
    const cmd = `bash /usr/bin/LTBOTVPN/buatTRO ${username} ${expired} ${quota} ${limitIP}`;
    conn.exec(cmd, (err, stream) => {
      if (err) return lunaticreply('❌ Gagal eksekusi script di VPS!');

      let output = '';
      stream.on('data', chunk => output += chunk.toString());
      stream.stderr.on('data', errChunk => output += errChunk.toString());
      stream.on('close', () => {
        conn.end();
        if (!output.trim()) {
          return lunaticreply('⚠️ Tidak ada output dari script. Cek manual di VPS.');
        }

        const beautify = '```' + output.trim() + '```';
        lunaticreply(`✅ *Trojan berhasil dibuat:*\n\n${beautify}`);
      });
    });
  }).on('error', err => {
    lunaticreply(`❌ Gagal konek ke VPS: ${err.message}`);
  }).connect({
    host: target.ip,
    port: 22,
    username: 'root',
    password: target.pass
  });
};